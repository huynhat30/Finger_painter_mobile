package com.example.coursework1_1;

import android.app.Activity;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.graphics.Color;

public class MainActivity extends AppCompatActivity {

    FingerPainterView myFingerPainterView;

    public static final int MY_COLOUR_CODE = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myFingerPainterView = new FingerPainterView(this);
        myFingerPainterView.findViewById(R.id.fingerPainterView);

    }


    public void colourChooser(View view) {
        Log.d("psyng1", "button colour pressed");

        Intent intent = new Intent(MainActivity.this, ColourChoose.class);
        startActivityForResult(intent, MY_COLOUR_CODE);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == MY_COLOUR_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                assert data != null;
                Bundle bundle = data.getExtras();
                String colourID = bundle.getString("colour");
                myFingerPainterView.setColour(Color.GREEN);
            } else if (resultCode == Activity.RESULT_CANCELED) {
                Log.d("FingerPainter", "Activity canceled");
            }
        } else {
            Log.d("FingerPainter", "Activity canceled");
        }
    }
}