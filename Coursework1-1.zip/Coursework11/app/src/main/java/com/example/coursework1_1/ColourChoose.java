package com.example.coursework1_1;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class ColourChoose extends AppCompatActivity {

    public static Paint p_brush = new Paint();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_colour_choose);
    }
    public void redColour(View view){
        Log.d("psyng1", "button red colour pressed");

        Intent intent = new Intent();
        intent.putExtra("colour", "#E15555");
        setResult(Activity.RESULT_OK, intent);
        finish();
    }

    public void blueColour(View view){
        Log.d("psyng1", "button blue colour pressed");

        Intent intent = new Intent();
        intent.putExtra("colour", "#92C4EF");
        setResult(Activity.RESULT_OK, intent);
        finish();
    }
    public void blackColour(View view){
        Log.d("psyng1", "button black colour pressed");

        Intent intent = new Intent();
        intent.putExtra("colour", "#171616");
        setResult(Activity.RESULT_OK, intent);
        finish();
    }
    public void orangeColour(View view){
        Log.d("psyng1", "button orange colour pressed");

        Intent intent = new Intent();
        intent.putExtra("colour", "#FF9800");
        setResult(Activity.RESULT_OK, intent);
        finish();
    }
    public void greenColour(View view){
        Log.d("psyng1", "button green colour pressed");

        Intent intent = new Intent();
        intent.putExtra("colour", "#4CAF50");
        setResult(Activity.RESULT_OK, intent);
        finish();
    }
    public void yellowColour(View view){
        Log.d("psyng1", "button yellow colour pressed");

        Intent intent = new Intent();
        intent.putExtra("colour", "#FFEB3B");
        setResult(Activity.RESULT_OK, intent);
        finish();
    }
}